-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2024 at 11:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newlaravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `baskets`
--

CREATE TABLE `baskets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `Is_Payed` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `Name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'غذای سنتی', 'غذاهای بسیار سالم و مقوی که سلامت انسان تضمین شده است.', '2024-09-16 04:41:43', '2024-09-16 04:41:43'),
(2, 'غذای فست فودی', 'غذاهای بسیار مضر و ناسالم که سلامت انسان را به خطر می اندازد.', '2024-09-16 04:42:47', '2024-09-16 04:42:47'),
(3, 'غذاهای محلی', 'غذاهای محلی بسیار سالم و مقوی که در مناطق مختلفی از کشور درست میشوند.', '2024-09-16 18:12:36', '2024-09-16 18:12:36');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2024_09_14_104449_create_restaurants_table', 1),
(7, '2024_09_14_104643_create_categories_table', 1),
(8, '2024_09_14_104730_create_products_table', 1),
(9, '2024_09_15_184253_add_new_column_to_users_table', 2),
(10, '2024_09_16_103951_counter_to_restaurant', 3),
(11, '2024_09_16_144046_is_slide', 4),
(12, '2024_09_16_221106_description', 5),
(13, '2024_09_18_130404_description', 6),
(14, '2024_09_18_154707_create_wallets_table', 7),
(15, '2024_09_18_160650_create_baskets_table', 8),
(16, '2024_09_18_161839_create_product_baskets_table', 8),
(17, '2024_09_18_224024_restaurant_id', 9),
(18, '2024_09_18_231314_delete_count', 10),
(19, '2024_09_18_231655_delete_count', 11),
(20, '2024_09_18_231947_delete_count', 12),
(21, '2024_09_19_091021_delete_count', 13),
(22, '2024_09_19_104633_deleteuser_i_d', 14),
(23, '2024_09_19_105606_user_id', 15),
(24, '2024_09_19_110128_adduser_id', 16),
(25, '2024_09_20_005201_status__paying', 17),
(26, '2024_09_21_121719_create_cars_table', 18),
(27, '2024_09_22_091152_delete_table', 19);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('alireza.g84129@gmail.com', '$2y$10$1vlY7oOg6ftz/Uwxz1cbp.CmooFUY1Bc457kCY0rHDrqhCPtxNgme', '2024-09-15 13:38:51');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(2, 'App\\Models\\User', 1, 'Alireza', '3aa1b97057e7bbe76b40dcfcd120397ffe11f8de848e461f513c1b9784b6f2b1', '[\"*\"]', NULL, NULL, '2024-09-21 12:38:23', '2024-09-21 12:38:23'),
(5, 'App\\Models\\User', 1, 'Alireza', '37d262535ec5dab5c5ed6be07bf15a4f243c45963bfe7c73544b78e4de7c9291', '[\"*\"]', NULL, NULL, '2024-09-22 05:54:15', '2024-09-22 05:54:15'),
(7, 'App\\Models\\User', 1, 'Alireza', '6cbaa7287e9ca43fb7b7356ece3960539e027f27f0829aa0db399141abcf2b52', '[\"*\"]', '2024-09-22 10:41:09', NULL, '2024-09-22 10:40:24', '2024-09-22 10:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Price` int(11) NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `Name`, `Price`, `category_id`, `restaurant_id`, `created_at`, `updated_at`, `description`) VALUES
(1, 'مرغ سوخاری', 280000, 2, 6, '2024-09-16 20:24:14', '2024-09-18 10:12:50', '۴ عدد، سینه مرغ مزه دار شده، قارچ، پنیر پیتزا، جعفری، کره، خمیر یوفکا، به همراه یک عدد سس شرکتی'),
(2, 'پیتزا سه فر', 786000, 2, 6, '2024-09-16 20:24:58', '2024-09-18 10:06:27', 'ژامبون گوشت و مرغ، هات داگ فرانکفورتر، قارچ، زیتون، گوجه، فلفل دلمه ای، پنیر موزارلا، سس مخصوص، سیب زمینی سرخ شده'),
(3, 'سیب زمینی', 180000, 2, 6, '2024-09-16 20:25:36', '2024-09-18 10:13:32', '۸۰۰ گرم، سیب زمینی سرخ شده، سوسیس ۷۰%، بیکن ۹۰%، فیله سوخاری، قارچ و پنیر'),
(4, 'ساندویچ اولویه', 167000, 1, 6, '2024-09-16 20:40:50', '2024-09-18 10:11:18', 'سینه مرغ ریش ریش شده، سیب زمینی، سس مخصوص، خیارشور، بدون دورچین، بدون نان'),
(5, 'باقالی قاتوق', 240000, 3, 2, '2024-09-17 16:41:02', '2024-09-18 09:54:33', 'برنج، زرشک، سالاد، ترشی، ۱۰۰گرم گوشت'),
(6, 'کباب نگینی اصل', 990000, 1, 3, '2024-09-17 16:42:07', '2024-09-18 10:08:43', '۱۵۰ گرم (وزن خام) گوشت چرخ کرده، ۳۳۵ گرم برنج ساده به همراه ۳۰ گرم برنج زعفرانی (صددرصد ایرانی)، گوجه کبابی، کره ۱۵۰ گرم گوشت چرخ کرده، ۳۳۵ گرم برنج ساده'),
(7, 'فلافل ویژه', 89000, 1, 5, '2024-09-17 16:43:06', '2024-09-18 10:04:45', 'دونرگوشت کبابی، سس آلفردو، پیاز سرخ شده، پنیر مخصوص، سیب زمینی'),
(8, 'کباب ماهیچه گوسفندی', 1200000, 1, 3, '2024-09-17 16:44:03', '2024-09-18 10:09:27', '۱۵۰ گرم (وزن خام) گوشت چرخ کرده، ۳۳۵ گرم برنج ساده به همراه ۳۰ گرم برنج زعفرانی (صددرصد ایرانی)، گوجه کبابی، کره ۱۵۰ گرم گوشت چرخ کرده، ۳۳۵ گرم برنج ساده به همراه ۳۰ گرم برنج زعفرانی');

-- --------------------------------------------------------

--
-- Table structure for table `product_baskets`
--

CREATE TABLE `product_baskets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `basket_id` bigint(20) UNSIGNED DEFAULT NULL,
  `Counte` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `restaurant_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `Status_Paying` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_baskets`
--

INSERT INTO `product_baskets` (`id`, `product_id`, `basket_id`, `Counte`, `created_at`, `updated_at`, `restaurant_id`, `user_id`, `Status_Paying`) VALUES
(6, 5, NULL, 3, '2024-09-19 09:08:35', '2024-09-19 22:30:48', 2, 1, 1),
(7, 7, NULL, 3, '2024-09-19 09:09:18', '2024-09-19 22:22:21', 5, 1, 1),
(8, 2, NULL, 1, '2024-09-19 10:24:14', '2024-09-19 22:17:34', 6, 1, 1),
(9, 4, NULL, 2, '2024-09-19 11:13:47', '2024-09-19 21:58:39', 6, 2, 1),
(10, 3, NULL, 1, '2024-09-19 11:27:46', '2024-09-19 21:58:39', 6, 2, 1),
(11, 1, NULL, 1, '2024-09-19 22:19:35', '2024-09-19 22:20:26', 6, 1, 1),
(12, 8, NULL, 2, '2024-09-19 22:21:34', '2024-09-19 22:31:31', 3, 1, 1),
(13, 6, NULL, 1, '2024-09-19 22:30:05', '2024-09-19 22:31:31', 3, 1, 1),
(14, 4, NULL, 1, '2024-09-19 22:30:34', '2024-09-19 22:31:31', 6, 1, 1),
(15, 7, NULL, 2, '2024-09-19 22:54:59', '2024-09-19 22:55:42', 5, 1, 1),
(22, 8, NULL, 1, '2024-09-24 16:19:58', '2024-09-24 16:21:15', 3, 1, 1),
(23, 6, NULL, 1, '2024-09-24 16:20:04', '2024-09-24 16:21:15', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `Counter` int(11) NOT NULL DEFAULT 0,
  `Is_Slide` tinyint(1) NOT NULL DEFAULT 0,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `Title`, `Address`, `image`, `created_at`, `updated_at`, `Counter`, `Is_Slide`, `Description`) VALUES
(1, 'میخوش', 'تهران - سعادت آباد', '1726432466-01.jpg', '2024-09-15 17:04:26', '2024-09-20 17:17:31', 13, 0, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران میخوش با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا میخوش در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش .در </span><span style=\"font-size: 14pt;\">.جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>'),
(2, 'سنگسری', 'تهران - فیروزکوه', '1726432498-02.jpg', '2024-09-15 17:04:58', '2024-09-19 09:08:58', 13, 0, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران سنگسری با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا سنگسری در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش .در </span><span style=\"font-size: 14pt;\">.جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>'),
(3, 'مسلم', 'تهران - بازار بزرگ', '1726491804-07.jpg', '2024-09-15 17:05:32', '2024-09-24 16:20:04', 46, 0, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران مسلم با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا مسلم در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش .در </span><span style=\"font-size: 14pt;\">.جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>'),
(4, 'نایب قدیم', 'کرج - شهرک بعثت', '1726493631-03.jpg', '2024-09-15 17:06:00', '2024-09-22 13:42:59', 9, 1, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران نایب قدیم با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا نایب قدیم در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش .در </span><span style=\"font-size: 14pt;\">.جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>'),
(5, 'چنار', 'تهران - شهرک غرب', '1726432591-05.jpg', '2024-09-15 17:06:31', '2024-09-24 16:19:41', 39, 1, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران چنار با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا چنار در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش در </span><span style=\"font-size: 14pt;\">جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>'),
(6, 'سفر', 'تهران - بلوار دادمان', '1726432620-06.jpg', '2024-09-15 17:07:00', '2024-09-24 16:18:54', 32, 0, '<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">رستوران سفر با حدود نیم قرن تجربه در طبخ و تهیه انواع غذاهای اصیل و سنتی ایرانی و با استفاده از کادری مجرب و کار آزموده در میدان قیام تهران تاسیس شد. کیفیت بالای غذاهای ارائه شده ، استفاده از بهترین مواد اولیه، بکارگیری شیوه های نوین صنعتی و استقبال روزافزون مشتریان پشتوانه ای گردید.</span></p>\r\n<p style=\"text-align: right; line-height: 2;\"><span style=\"font-size: 14pt;\">&nbsp;تا سفر در جهت احداث و تکمیل سیستمی هدفمند با ساختاری عالی در پخت و ارائه غذاهای سنتی بصورت بسته بندی شده گام های خود را مصمم .تر از پیش .در&nbsp;</span><span style=\"font-size: 14pt;\">.جهت خدمتی ماندگار به مصرف کنندگان بردارد</span></p>\r\n<p style=\"text-align: right; line-height: 2;\">&nbsp;</p>');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'علیرضا گرمخورانی', 'alireza.g84129@gmail.com', NULL, '$2y$10$77NqsNnZdwhZBfvgGEJPcOGNT9Cf46tzASe.KICDp84tqIEGZhInm', NULL, '2024-09-15 13:37:39', '2024-09-15 13:37:39', 'admin'),
(2, 'امیرمهدی گرمخورانی', 'test@gmail.com', NULL, '$2y$10$687fHGi2upPESQG8lX3Sye/06KeKkCKRSbEzc5GQB9CFx7gb8Jd6S', NULL, '2024-09-15 16:45:21', '2024-09-15 16:45:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `Price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `Price`, `created_at`, `updated_at`) VALUES
(1, 1, 539000, '2024-09-19 14:57:32', '2024-09-24 16:21:15'),
(3, 2, 500000, '2024-09-19 23:26:15', '2024-09-19 23:26:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `baskets`
--
ALTER TABLE `baskets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `baskets_restaurant_id_foreign` (`restaurant_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_restaurant_id_foreign` (`restaurant_id`);

--
-- Indexes for table `product_baskets`
--
ALTER TABLE `product_baskets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_baskets_product_id_foreign` (`product_id`),
  ADD KEY `product_baskets_basket_id_foreign` (`basket_id`),
  ADD KEY `product_baskets_restaurant_id_foreign` (`restaurant_id`),
  ADD KEY `product_baskets_user_id_foreign` (`user_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wallets_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `baskets`
--
ALTER TABLE `baskets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_baskets`
--
ALTER TABLE `product_baskets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `baskets`
--
ALTER TABLE `baskets`
  ADD CONSTRAINT `baskets_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`);

--
-- Constraints for table `product_baskets`
--
ALTER TABLE `product_baskets`
  ADD CONSTRAINT `product_baskets_basket_id_foreign` FOREIGN KEY (`basket_id`) REFERENCES `baskets` (`id`),
  ADD CONSTRAINT `product_baskets_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_baskets_restaurant_id_foreign` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants` (`id`),
  ADD CONSTRAINT `product_baskets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
